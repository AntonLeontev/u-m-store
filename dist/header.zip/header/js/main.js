function showWindow(trigger, window){
    document.querySelector(trigger).addEventListener('click', (e)=>{
        e.preventDefault();
        document.querySelectorAll(window).forEach(item=>{
            item.style.display = 'block';
        });
        if (trigger == '.catalog__btn--one'){
            document.querySelector(trigger).style.display = 'none';
            document.querySelector('.catalog__btn--two').style.display = 'block';
        }
    });
}
showWindow('#headerCity', '#cityWindow');

if (document.documentElement.clientWidth < 600){
    document.querySelector('.header__city').textContent = '';
    document.querySelector('.header__phone a').textContent = '';
}

function clickcity(city, input, itog){
    document.querySelectorAll(city).forEach(item => {
        item.addEventListener('click', ()=>{
            item.classList.remove('active');
            document.querySelector(input).value = item.textContent;
            document.querySelector(itog).textContent = item.textContent;
            document.querySelectorAll(city).forEach(block => {
                block.classList.remove('active');
                item.classList.add('active');
            });
            if (document.documentElement.clientWidth > 800){
                document.querySelector('.header__city').textContent = item.textContent;
            }
        });
    });
}
clickcity('#cityPosition', '#citySearch', '#cityItog');

function closeWindow(trigger, window){
    document.querySelector(trigger).addEventListener('click', (e)=>{
        e.preventDefault();
        document.querySelectorAll(window).forEach(item=>{
            item.style.display = 'none';
        });
        if (trigger == '.catalog__btn--two'){
            document.querySelector(trigger).style.display = 'none';
            document.querySelector('.catalog__btn--one').style.display = 'block';
        }
    });
}
try{
    closeWindow('.catalog__btn--two', '.catalog__hide');
} catch{}
closeWindow('#windowClose', '#headerWindow');
closeWindow('#cityClose', '#cityWindow');


function showKatalog(trigger, window){
    document.querySelector(trigger).addEventListener('click', (e)=>{
        e.preventDefault();
        document.querySelector(window).style.display = 'flex';
    });
}
try{
    showKatalog('#headerA', '#headerWindow');
} catch{}

try{
    showKatalog('#headerMobMenu', '#headerWindow');
} catch{};